1. Needed Software

	You need a local server to run php
	Link: a. http://www.wampserver.com/en/
	Wamp server need Visual C++ MSVCR110.dll & MSVCR120.dll

	Link: b. https://www.microsoft.com/en-us/download/details.aspx?id=30679
		 https://www.microsoft.com/en-us/download/details.aspx?id=40784

	Install Visual C++ first then WAMP server.


2. Run application by your browser, if you cann't then follow my video.



	Note: SMTP example format

		smtp.gmail.com:587:tls:Example@gmail.com:ExamplePassword123

	Email: 
		iktakhairul@gmail.com
		iktakhairul8606@gmail.com
		linuxfedoraneobux@gmail.com